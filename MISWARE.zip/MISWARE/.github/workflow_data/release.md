## ⬇️ Download
>### [🖥️ Web Updater (chrome)](https://flipper-xtre.me/update) [recommended]

>### [🐬 qFlipper Package (.tgz)](https://github.com/Flipper-XFW/Xtreme-Firmware/releases/download/{VERSION_TAG}/{ARTIFACT_TGZ})

>### [📦 Zipped Archive (.zip)](https://github.com/Flipper-XFW/Xtreme-Firmware/releases/download/{VERSION_TAG}/{ARTIFACT_ZIP})

**Check the [install guide](https://github.com/Flipper-XFW/Xtreme-Firmware#install) if you're not sure, or [join our Discord](https://discord.gg/flipper-xtreme) if you have questions or encounter issues!**

## ❤️ Support
If you like what you're seeing, **please consider donating to us**. We won't ever put this behind a paywall, but we'd still appreciate a few bucks!

- **[Patreon](https://patreon.com/CynthiaLabs)**: ❤️ Account needed, subscription with perks across my entire org.
- **[Wire-transfer](https://bunq.me/ClaraK)**: No account needed, one-time
- **[Paypal](https://paypal.me/RdX2020)**: Account needed, one-time
- **[ko-fi](https://ko-fi.com/cynthialabs)**: No account needed, one-time
- **Monero**: `41kyWeeoVdK4quzQ4M9ikVGs6tCQCLfdx8jLExTNsAu2SF1QAyDqRdjfGM6EL8L9NpXwt89HJeAoGf1aoArk7nDr4AMMV4T`

**Thanks for all your support <3**

## 🚀 Changelog
{CHANGELOG}

<!--- <HOTFIXES>
### Hotfixes:

  [//]: <NEXT_HOTFIX>

  **If you have any of the above issues, please re-download and re-install!**
<HOTFIXES> -->
